var map;
var marker;
var markersArray = [];
var estado="inicio";
function initialize() {


	showLocation();//mapa que muestra la localizacion de tu piano
	
}


/************************LOCALIZACION DEL PIANO EN EL MAPA***************************************************/
function showLocation(){
var latlng = getCoordenates();
var mapOptions;


	if(latlng==false){
		 latlng = new google.maps.LatLng(40.367727, -3.680041);
		 mapOptions = {zoom: 10,center: latlng}
		 map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
	}
	else{
mapOptions = {zoom: 10,center: latlng}
map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
}
}

function codeAddress() {
	var blanco= " ";
	var dropdownCountry = document.getElementById('country_id');
  	var country = dropdownCountry.options[dropdownCountry.selectedIndex].text;
  	var city= document.getElementById('city').value;
  	var postal_code= document.getElementById('postal_code').value;
	var address = document.getElementById('address').value;
	var geocoder= new google.maps.Geocoder();
	var completeaddress=country+blanco+city+blanco+postal_code+blanco+address;
	 geocoder.geocode( { 'address': completeaddress}, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
     	clearOverlays();
      map.setCenter(results[0].geometry.location);
      map.setZoom(15);
		addMarker(results[0].geometry.location,"update");
      /*var marker = new google.maps.Marker({
          map: map,
          position: results[0].geometry.location
      });*/
 
    } else {
      alert('Geocode was not successful for the following reason: ' + status);
    }
  });
}
function addMarker(location,estado) {
 marker = new google.maps.Marker({
    position: location,
    map: map
  });
 if(!(estado=="inicio")){
  setCoordenates(marker);
  }
  markersArray.push(marker);
 
}
function getCoordenates(){
 lat=document.getElementById('latitude').value
 lng=document.getElementById('longitude').value
		if(lat!=0&&lng!=0){ 
		var latlng= new google.maps.LatLng(lat, lng);
		return latlng;
		}
		else{
		return false;
		}
}

function setCoordenates(marker){
var latlng=marker.getPosition();
lat=latlng.lat();
lng=latlng.lng();

document.getElementById('latitude').value = lat;
document.getElementById('longitude').value = lng;

}
function clearOverlays() {
	 if (markersArray) {
    for (i in markersArray) {
      markersArray[i].setMap(null);
    }
  }
 }

function showOverlays() {
  if (markersArray) {
    for (i in markersArray) {
      markersArray[i].setMap(map);
    }
  }
}


function deleteOverlays() {
	//if(marker)marker.setMap(null);  
  if (markersArray) {
    for (i in markersArray) {
      markersArray[i].setMap(null);
    }
    markersArray.length = 0;
  }
}
//GOOGLE UNDEFINED
google.maps.event.addDomListener(window, 'load', initialize);