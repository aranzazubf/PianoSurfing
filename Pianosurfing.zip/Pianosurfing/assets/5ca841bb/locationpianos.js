var map;
var marker;
var markersArray = [];
var map_index;
var parser=new DOMParser();//DIEGO
var xml=parser.parseFromString('<?php echo str_replace("\n","",$markersXML);?>','text/xml');//DIEGO
 console.log(xml);//DIEGO
function initialize() {

	//showPianosAra();//mapa de la lista de pianos
	showPianosDiego();//mapa de la lista de pianos
	//showLocation();//mapa que muestra la localizacion de tu piano
	
}
function showPianosAra(){
var coordenadas="<?php echo Piano::model()->CoordenadasPianos();?>";;
getCoordenasPianosCreados(coordenadas); 
var mapOptions;
	var  latlng = new google.maps.LatLng(40.367727, -3.680041);
		 mapOptions = {zoom: 10,center: latlng}
map_index = new google.maps.Map(document.getElementById('map-canvas-index'), mapOptions);

}
function addMarkerIndex(location) {
	alert("Your locationMarker: " + location.lat() + location.lng());
  marker = new google.maps.Marker({
    position: location,
    map: map_index
  });

  markersArray.push(marker);
 showOverlays();
}
function getCoordenasPianosCreados(pianos_creados){	
	var i=0;
	var coordedas;
	for(i=1;i<pianos_creados.length;i++){
 		 marker=new google.maps.LatLng(pianos_creados['lat'][i], pianos_creados['lng'][i]);
 		 addMarkerIndex(marker);
	}
	

}

function showPianosDiego(){
var mapOptions;
	var  latlng = new google.maps.LatLng(40.367727, -3.680041);
		 mapOptions = {zoom: 5,center: latlng}
  mapview = new google.maps.Map(document.getElementById("map-canvas-index"), mapOptions);
 window.map = mapview;
 var markers = xml.documentElement.getElementsByTagName("marker");
 //var html = new Array();
  for (var i = 0; i < markers.length; i++) {
  	console.log(marker[i].getAttribute("lat"));
	  // var id = markers[i].getAttribute("id");
	   var point = new google.maps.LatLng(
	       parseFloat(markers[i].getAttribute("lat")),
	       parseFloat(markers[i].getAttribute("long")));
	 
	  // html[id] = "<b>" + id + "</b><br><br>" + finca;
		
	   var marker = new google.maps.Marker({
	     map: mapview,
	     position: point,
	     //title: id,
		//  icon : iconBase + id + '.png'
	   });
	  /*  var contentString = '<p>Nodo Por Defecto</p>';
	    var infowindow = new google.maps.InfoWindow({
	      content: contentString
	  		});
	   google.maps.event.addListener(marker, 'click', function() {
	    		
	    		contentString = '<div style="width:100px;height:60px;">Nodo: '+html[this.getTitle()].toUpperCase()+'</div>';
	    		infowindow.setContent(contentString);
	    		infowindow.open(map,this);

	  	});*/ 
  
  }
}


function addMarker(location,estado) {
	alert("Your locationMarker: " + location.lat() + location.lng());
  marker = new google.maps.Marker({
    position: location,
    map: map
  });

alert("Your locationMarkerPOs: " + lat + lng + estado);
 if(!estado=="inicio")
  setCoordenates(marker);
  markersArray.push(marker);
 
}
function getCoordenates(){
 lat=document.getElementById('latitude').value
 lng=document.getElementById('longitude').value
		if(lat!=0&&lng!=0){ 
		var latlng= new google.maps.LatLng(lat, lng);
		return latlng;
		}
		else{
		return false;
		}
}

function setCoordenates(marker){
var latlng=marker.getPosition();
lat=latlng.lat();
lng=latlng.lng();
document.getElementById('latitude').value = lat;
document.getElementById('longitude').value = lng;

}
function clearOverlays() {
	 if (markersArray) {
    for (i in markersArray) {
      markersArray[i].setMap(null);
    }
  }
 }

function showOverlays() {
  if (markersArray) {
    for (i in markersArray) {
      markersArray[i].setMap(map);
    }
  }
}


function deleteOverlays() {
	//if(marker)marker.setMap(null);  
  if (markersArray) {
    for (i in markersArray) {
      markersArray[i].setMap(null);
    }
    markersArray.length = 0;
  }
}
//GOOGLE UNDEFINED
google.maps.event.addDomListener(window, 'load', initialize);