var mapview;
var marker;
var markersArray = [];
var map_index;
 
function showPianos(xml){
console.log(xml);


var markers = xml.documentElement.getElementsByTagName("marker");
console.log(markers.length);
 /*for (var i = 0; i < markers.length; i++) {
console.log( parseFloat(markers[i].getAttribute("lat")));
console.log( parseFloat(markers[i].getAttribute("long")));
   var point = new google.maps.LatLng(
       parseFloat(markers[i].getAttribute("lat")),
       parseFloat(markers[i].getAttribute("long")));
console.log( point);
    marker = new google.maps.Marker({
	      position: point,
			map: mapview
	     //title: id,
		//  icon : iconBase + id + '.png'
  });
   markersArray.push(marker);
 }*/
 var point2 = new google.maps.LatLng(
  33.888657 ,
      65.104980 	 );
console.log( point2);
    marker = new google.maps.Marker({
	      position: point2,
			map: mapview});
 showOverlays();
}
function showOverlays() {
  if (markersArray) {
    for (i in markersArray) {
      markersArray[i].setMap(mapview);
    }
  }
}
function addMarkerIndex(location) {
	alert("Your locationMarker: " + location.lat() + location.lng());
  marker = new google.maps.Marker({
    position: location,
    map: mapview
  });

  markersArray.push(marker);
}

 
function initialize() {
var mapOptions="";
console.log(mapOptions);
var  latlng = new google.maps.LatLng(40.367727, -3.680041);
mapOptions = {zoom: 5,center: latlng}
console.log(mapOptions);
mapview = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
  marker = new google.maps.Marker({
    position: latlong,
    map: mapview
  });
	//mapa de la lista de pianos
	
	
}
 $.ajax({	'type':'POST',
'url':'markerspianos',
'data':{'cache':false,},
dataType : "json", 
}).done(function(data){

 
var parser=new DOMParser();//DIEGO
//var xml=parser.parseFromString('<?php echo str_replace("\n","",$data);?>','text/xml');
 // console.log("antes"+xml);
 var xml1=parser.parseFromString(data.replace("\n",""),"text/xml");
//var xml=JSON.parse((data.replace("\n","")));//DIEGO
 alert(xml1);//DIEGO
 
showPianos(xml1);
}
);


//GOOGLE UNDEFINED
google.maps.event.addDomListener(window, 'load', initialize);