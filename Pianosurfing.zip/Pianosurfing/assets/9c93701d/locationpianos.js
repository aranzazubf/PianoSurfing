var mapview;
var marker;
var markersArray = [];
var map_index;
function showPianos(xml){
var markers = xml.documentElement.getElementsByTagName("marker");
 for (var i = 0; i < markers.length; i++) {
   var point = new google.maps.LatLng(
       parseFloat(markers[i].getAttribute("lat")),
       parseFloat(markers[i].getAttribute("long")));
    	 marker = new google.maps.Marker({
	      position: point,
			map: mapview
	     //title: id,
		//  icon : iconBase + id + '.png'
  });
  var contentString = '<p>Nodo Por Defecto</p>';
	    var infowindow = new google.maps.InfoWindow({
	      content: contentString
	  		});
	  		 google.maps.event.addListener(marker, 'click', function() {
	    		
	    		contentString = '<div style="width:100px;height:60px;">Nodo: ''</div>';
	    		infowindow.setContent(contentString);
	    		infowindow.open(mapview,this);

	  	}); 
   //markersArray.push(marker);
 }
}


 
function initialize() {
var mapOptions="";
console.log(mapOptions);
var  latlng = new google.maps.LatLng(40.367727, -3.680041);
mapOptions = {zoom: 5,center: latlng}
console.log(mapOptions);
mapview = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);


 $.ajax({	'type':'POST',
'url':'markerspianos',
'data':{'cache':false,},
dataType : "json", 
}).done(function(data){

 
var parser=new DOMParser();//DIEGO
 var xml1=parser.parseFromString(data.replace("\n",""),"text/xml");

showPianos(xml1);
}
);}


//GOOGLE UNDEFINED
google.maps.event.addDomListener(window, 'load', initialize);