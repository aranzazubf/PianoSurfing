var map;
var marker;
var markersArray = [];
var map_index;
//var parser=new DOMParser();//DIEGO
//var xml=parser.parseFromString('<?php echo str_replace("\n","",$markers);?>','text/xml');//DIEGO

 
 
function showPianos(xml){
var mapOptions;
	var  latlng = new google.maps.LatLng(40.367727, -3.680041);
		 mapOptions = {zoom: 5,center: latlng}
  mapview = new google.maps.Map(document.getElementById("map-canvas-index"), mapOptions);
 window.map = mapview;
 var markers = xml.documentElement.getElementsByTagName("marker");

console.log(markers.length);

  for (var i = 0; i < markers.length; i++) {
  	console.log(marker[i].getAttribute("lat"));

	   var point = new google.maps.LatLng(
	       parseFloat(markers[i].getAttribute("lat")),
	       parseFloat(markers[i].getAttribute("long")));

		
	   var marker = new google.maps.Marker({
	     map: mapview,
	     position: point,
	     //title: id,
		//  icon : iconBase + id + '.png'
	   });

  
  }
}
function addMarkerIndex(location) {
	alert("Your locationMarker: " + location.lat() + location.lng());
  marker = new google.maps.Marker({
    position: location,
    map: map_index
  });

  markersArray.push(marker);

}

 
function initialize() {



	//mapa de la lista de pianos
	
	
}
 $.ajax({	'type':'POST',
'url':'markerspianos',
'data':{'cache':false,},

}).done(function(data){
	alert(data);
 console.log(data);
var parser=new DOMParser();//DIEGO
var xml=parser.parseFromString('<?php echo str_replace("\n","",$data);?>','text/xml');
//var xml=parser.parseFromString(str_replace("\n","",data));//DIEGO
 console.log(xml);//DIEGO
 
showPianos(xml);
}
);


//GOOGLE UNDEFINED
google.maps.event.addDomListener(window, 'load', initialize);