var mapview;
var marker;
var markersArray = [];
var map_index;

function showPianos(xml){
var markers = xml.documentElement.getElementsByTagName("marker");
var html = new Array();
 for (var i = 0; i < markers.length; i++) {
   var point = new google.maps.LatLng(
       parseFloat(markers[i].getAttribute("lat")),
       parseFloat(markers[i].getAttribute("long")));
	var id=markers[i].getAttribute('id');
			var user=markers[i].getAttribute('user');
			var type=   markers[i].getAttribute('type');
			  var marca= markers[i].getAttribute('marca');
			  var model= markers[i].getAttribute('model');
			  var year= markers[i].getAttribute('year');
	  			var edad= markers[i].getAttribute('edad');
			  var status= markers[i].getAttribute('status');        
        
    	 marker = new google.maps.Marker({
	      position: point,
			map: mapview,
			
	     title: id,
		//  icon : iconBase + id + '.png'
  });
 	html[id] = "<b>"+user+"</b><br>"+edad+"<br>"+marca+"  |  "+type+"  | " + model+ "<br>"+ year +"|" +"status: "+status+ "/10"+"<br> <a class=link_operations href='<?php echo Yii::app()->request->baseUrl().'/'.piano/view?id="+id+"?>'>View</a>";
 	var contentString = '<p>Nodo Por Defecto</p>';
		    		    var infowindow = new google.maps.InfoWindow({
	      content: contentString
	  		});
	  		 google.maps.event.addListener(marker, 'click', function() {
		 contentString = '<div style="width:300px;height:150px;"><label class="viewlista2">'+html[this.getTitle()]+'</label></div>';	
	    	//	contentString = '<div style="width:200px;height:100px;"><b>'+this.getPosition()+'</div>';
	    		//.' comparte: '+type+'\n Marca: ' + marca +'\n Modelo: ' + model + '\n Año: '+ year +'\n Estado:' +status+ '/10</div>';
	    		infowindow.setContent(contentString);
	    		infowindow.open(mapview,this);

	  	}); 
   //markersArray.push(marker);
 }
}


 
function initialize() {
var mapOptions="";
console.log(mapOptions);
var  latlng = new google.maps.LatLng(40.367727, -3.680041);
mapOptions = {zoom: 5,center: latlng}
console.log(mapOptions);
mapview = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);


 $.ajax({	'type':'POST',
'url':'markerspianos',
'data':{'cache':false,},
dataType : "json", 
}).done(function(data){
console.log(data);
 
var parser=new DOMParser();//DIEGO
 var xml1=parser.parseFromString(data.replace("\n",""),"text/xml");

showPianos(xml1);
}
);}


//GOOGLE UNDEFINED
google.maps.event.addDomListener(window, 'load', initialize);