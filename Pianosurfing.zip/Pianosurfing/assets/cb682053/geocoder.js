var map;
var marker;
var markersArray = [];
var map_index;
function initialize() {

//	showPianos();//mapa de la lista de pianos
	showLocation();//mapa que muestra la localizacion de tu piano
	//var coordenadas="<?php echo Piano::model()->CoordenadasPianos();?>";
	//var coordenadas_pianos_creados=getCoordenasPianosCreados(coordenadas); 
//	addMarkerindex(coordenas_pianos_creados);

	
}
function showPianos(){
var coordenadas="<?php echo Piano::model()->CoordenadasPianos();?>";;
getCoordenasPianosCreados(coordenadas); 
var mapOptions;

mapOptions = {zoom: 3}
map_index = new google.maps.Map(document.getElementById('map-canvas-index'), mapOptions);

}
function addMarkerIndex(location) {
	alert("Your locationMarker: " + location.lat() + location.lng());
  marker = new google.maps.Marker({
    position: location,
    map: map_index
  });

  markersArray.push(marker);
 showOverlays();
}



function getCoordenasPianosCreados(pianos_creados){	
	int i;
	var coordedas[];
	for(i=1;i<pianos_creados.length;i++){
 		 marker=new google.maps.LatLng(pianos_creados['lat'][i], pianos_creados['lng'][i]);
 		 addMarkerIndex(marker);
	}
	

}
function showLocation(){
var latlng = getCoordenates();
var mapOptions;
var estado="inicio";
console.log(latlng);
	if(latlng==false){
		 latlng = new google.maps.LatLng(40.367727, -3.680041);
		 mapOptions = {zoom: 10,center: latlng}
		 map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
	}
	else{
mapOptions = {zoom: 10,center: latlng}
map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
addMarker(latlng,estado);}
}

function codeAddress() {
	var blanco= " ";
var dropdownCountry = document.getElementById('country_id');
  var country = dropdownCountry.options[dropdownCountry.selectedIndex].text;
  var city= document.getElementById('city').value;
  var postal_code= document.getElementById('postal_code').value;
var address = document.getElementById('address').value;
var geocoder= new google.maps.Geocoder();
var completeaddress=country+blanco+city+blanco+postal_code+blanco+address;


  geocoder.geocode( { 'address': completeaddress}, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
    	
    	clearOverlays();
      map.setCenter(results[0].geometry.location);
      map.setZoom(15);
		 addMarker(results[0].geometry.location,"update");
      /*var marker = new google.maps.Marker({
          map: map,
          position: results[0].geometry.location
      });*/

 alert("Your location: " + completeaddress);
    } else {
      alert('Geocode was not successful for the following reason: ' + status);
    }
  });
}
function addMarker(location,estado) {
	alert("Your locationMarker: " + location.lat() + location.lng());
  marker = new google.maps.Marker({
    position: location,
    map: map
  });

alert("Your locationMarkerPOs: " + lat + lng + estado);
 if(!estado=="inicio")
  setCoordenates(marker);
  markersArray.push(marker);
 
}

function setCoordenates(marker){

var latlng=marker.getPosition();
 lat=latlng.lat();
 lng=latlng.lng();

document.getElementById('latitude').value = lat;
document.getElementById('longitude').value = lng;


}

function getCoordenates(){


 lat=document.getElementById('latitude').value
 lng=document.getElementById('longitude').value

if(lat!=0&&lng!=0){ 
var latlng= new google.maps.LatLng(lat, lng);
return latlng;
}
else{
return false;}
}
function clearOverlays() {
  
  
  if (markersArray) {
    for (i in markersArray) {
      markersArray[i].setMap(null);
    }
  }}

// Shows any overlays currently in the array
function showOverlays() {
  if (markersArray) {
    for (i in markersArray) {
      markersArray[i].setMap(map);
    }
  }
}

// Deletes all markers in the array by removing references to them
function deleteOverlays() {
	//if(marker)marker.setMap(null);  

  if (markersArray) {
    for (i in markersArray) {
      markersArray[i].setMap(null);
    }
    markersArray.length = 0;
  }
}
//GOOGLE UNDEFINED
google.maps.event.addDomListener(window, 'load', initialize);