var mapview;
var marker;
var markersArray = [];
var map_index;
var id;
var user;
var type;
var marca;
var model;
var year;
var status;
function showPianos(xml){
var markers = xml.documentElement.getElementsByTagName("marker");
 for (var i = 0; i < markers.length; i++) {
   var point = new google.maps.LatLng(
       parseFloat(markers[i].getAttribute("lat")),
       parseFloat(markers[i].getAttribute("long")));
	 id=markers[i].getAttribute('id');
			 user=markers[i].getAttribute('user');
			 type=   markers[i].getAttribute('type');
			   marca= markers[i].getAttribute('marca');
			   model= markers[i].getAttribute('model');
			   year= markers[i].getAttribute('year');
			   status= markers[i].getAttribute('status');        
        
    	 marker = new google.maps.Marker({
	      position: point,
			map: mapview,
			
	     title: user,
		//  icon : iconBase + id + '.png'
  });
 //var html = new Array();
 //html[id] = "<b>" + id + "</b><br><br>" + finca;
 	contentString = '<div style="width:200px;height:100px;"><b>'+user+'</b><br>'+type+'                   '+ marca +'<br>' + model +'                   '+ year +'<br>' +status+ '/10</div>'+
	    		'<br> <a href=http://localhost/Pianosurfing/index.php/piano/view?id='+id+'>View</a></div>';
	    	
	    var infowindow = new google.maps.InfoWindow({
	      content: contentString
	  		});
	  		 google.maps.event.addListener(marker, 'click', function() {
	    	//	contentString = '<div style="width:200px;height:100px;"><b>'+this.getPosition()+'</div>';
	    		//.' comparte: '+type+'\n Marca: ' + marca +'\n Modelo: ' + model + '\n Año: '+ year +'\n Estado:' +status+ '/10</div>';
	    		infowindow.setContent(contentString);
	    		infowindow.open(mapview,this);

	  	}); 
   //markersArray.push(marker);
 }
}


 
function initialize() {
var mapOptions="";
console.log(mapOptions);
var  latlng = new google.maps.LatLng(40.367727, -3.680041);
mapOptions = {zoom: 5,center: latlng}
console.log(mapOptions);
mapview = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);


 $.ajax({	'type':'POST',
'url':'markerspianos',
'data':{'cache':false,},
dataType : "json", 
}).done(function(data){
console.log(data);
 
var parser=new DOMParser();//DIEGO
 var xml1=parser.parseFromString(data.replace("\n",""),"text/xml");

showPianos(xml1);
}
);}


//GOOGLE UNDEFINED
google.maps.event.addDomListener(window, 'load', initialize);