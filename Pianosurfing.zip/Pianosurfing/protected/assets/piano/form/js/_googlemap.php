 <script type="text/javascript">
 var parser=new DOMParser();
 var xml=parser.parseFromString('<?php echo str_replace("\n","",$markersXML);?>','text/xml');
 console.log(xml);
function actualiza_coordenadas(obj)
{
lat = obj.substr(0,obj.indexOf(','));
lng = obj.substr(obj.indexOf(',')+1,obj.length);
map.setCenter(new google.maps.LatLng(lat,lng));	
}
function initialize() {
  var mapOptions = {
    zoom: 16,
    zoomControl: true,
    center: new google.maps.LatLng(<?php echo key($array_redes); ?>),
    mapTypeId: google.maps.MapTypeId.HYBRID
  }
  var map = new google.maps.Map(document.getElementById("mapasearch"), mapOptions);
  window.map = map;
  var markers = xml.documentElement.getElementsByTagName("marker");
  var html = new Array();
 <?php
if ((strpos($_SERVER['HTTP_HOST'],'romeo') === false) && (strpos($_SERVER['HTTP_HOST'],'localhost') === false))
		{
			/* MODO PRODUCCIÓN */

?>
	    	var iconBase = 'http://clientes.monet-ti.com/images/iconos_maps/number_';
<?php
		}
		else
		{
				/* MODO DESARROLLO */
		?>
			  var iconBase = 'http://romeo.det.uvigo.es/MonetTI/images/iconos_maps/number_';
		<?php					
		}
  		?>
  for (var i = 0; i < markers.length; i++) {
	   
	   var id = markers[i].getAttribute("id");
	   var point = new google.maps.LatLng(
	       parseFloat(markers[i].getAttribute("lat")),
	       parseFloat(markers[i].getAttribute("long")));
	   var finca = markers[i].getAttribute("finca");
	   html[id] = "<b>" + id + "</b><br><br>" + finca;
		
	   var marker = new google.maps.Marker({
	     map: map,
	     position: point,
	     title: id,
		  icon : iconBase + id + '.png'
	   });
	    var contentString = '<p>Nodo Por Defecto</p>';
	    var infowindow = new google.maps.InfoWindow({
	      content: contentString
	  		});
	   google.maps.event.addListener(marker, 'click', function() {
	    		
	    		contentString = '<div style="width:100px;height:60px;">Nodo: '+html[this.getTitle()].toUpperCase()+'</div>';
	    		infowindow.setContent(contentString);
	    		infowindow.open(map,this);

	  	}); 
  
  }
}
	
	
 
function loadScript() {
  var script = document.createElement("script");
  script.type = "text/javascript";
  script.src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyDVVCoH9n5wARb1a8EfcBclJsH0a9tIhPc&sensor=false&callback=initialize";
  document.body.appendChild(script);

}

/*window.onload = loadScript;*/
</script>