<?php

class GlobalBController extends Controller
{

/**/

public function beforeAction($action) {
    if( parent::beforeAction($action) ) {
 // 		 $assetsDir = dirname(__FILE__).'/../../assets';
  //     $cs = Yii::app()->clientScript;
  //  	 $cs->registerScriptFile(Yii::app()->assetManager->publish($assetsDir.'/js/geocoder.js'),CclientScript::POS_END);
	//	 $cs->registerScriptFile("https://maps.googleapis.com/maps/api/js?v=3.exp",CclientScript::POS_END);
        return true;
    }
    return false;
}

}
?>