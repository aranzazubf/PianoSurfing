<?php
return CMap::mergeArray(

/*
 	 ********Este archivo es el complemento del main para el DESARROLLO-PRUEBA*******
 	 */
	require(dirname(__FILE__).'/main.php'),
	
	array(
	/*
	 ********Modulos: GII ********
 	 */
		'modules'=>array(
	/*************HERRAMIENTA GII PARA CREAR ACTIVER RECORD CON LAS TABLES DE LA BASE DE DATOS*******
    *
    */
    		'gii'=>array(
			'class'=>'system.gii.GiiModule',
			'password'=>'35467557q',
			// If removed, Gii defaults to localhost only. Edit carefully to taste.
			'ipFilters'=>array('127.0.0.1','::1'),
		),
	
	),
	/*
 	 ********Componentes: Conexion a base de datos de desarrollo de prueba (local), Logging********
 	 */
		'components'=>array(
			
		
			'db'=>array(
				'connectionString' => 'mysql:host=localhost;dbname=pianosurfingbase',
				'emulatePrepare' => true,
				'username' => 'ara',
				'password' => '35467557q',
				'charset' => 'utf8',
				'tablePrefix' => 'tbl_',
				),
				
		  'log'=>array(
			'class'=>'CLogRouter',
			'routes'=>array(
				array(
					'class'=>'CFileLogRoute',
					'levels'=>'error, warning, trace, info',
				),
				// uncomment the following to show log messages on web pages
				
				
				
			),
		),
			
			 
	),
)
);
