<?php

// uncomment the following to define a path alias
// Yii::setPathOfAlias('local','path/to/local-folder');

// This is the main Web application configuration. Any writable
// CWebApplication properties can be configured here.


/**********************BACKEND***************************/
$backend=dirname(dirname(__FILE__));
$frontend=dirname($backend);
Yii::setPathOfAlias('backend', $backend);



return array(

	/*
	 ********Establecemos los Paths de las carpetas********
	 */
	'basePath' => $frontend,
 	'controllerPath' => $backend.'/controllers',
	'viewPath' => $backend.'/views',
	'runtimePath' => $backend.'/runtime',


 

	/*
 	 ********Determinamos el nombre de nuestra app********
 	 */
		
	'name'=>'PianoSurfing',
	'defaultController' => 'user/profile', 
	
	/*
	 * preloading 'log' component
	 */
	 
	'preload'=>array('log'),
	
	/*
 	 ********Determinamos el lenguaje********
 	 */
	//'sourceLanguage'=>'en',
	'language' => 'es',

	/*
 	 ********Importamos los archivos necesarios********
 	 */
	
	'import'=>array(
		'backend.models.*',
		'backend.components.*',
		'application.models.*',
		'application.components.*',
		'application.modules.user.models.*',//modulo user
      'application.modules.user.components.*',
      'application.extensions.mail.*',
      'application.modules.user.*',
      'application.modules.message.*',
		'application.modules.message.models.*',
 		'application.modules.message.components.*',
		'application.extensions.galleryManager.models.*',
      'application.extensions.galleryManager.*',
      'application.extensions.image.*',      
      'ext.mail.YiiMailMessage',//modulo user
	),
	
	/*
	 ********Modulos: User ********
 	 */
	
	'modules'=>array(
	
		'user'=>array(
            # encrypting method (php hash function)
            'hash' => 'md5',
 
            # send activation email
            'sendActivationMail' => true,
 
            # allow access for non-activated users
            'loginNotActiv' => false,
 
            # activate user on registration (only sendActivationMail = false)
            'activeAfterRegister' => false,
 
            # automatically login from registration
            'autoLogin' => true,
 
            # registration path
            'registrationUrl' => array('/user/registration'),
 
            # recovery password path
            'recoveryUrl' => array('/user/recovery'),
 
            # login form path
            'loginUrl' => array('/user/login'),
 
            # page after login
            'returnUrl' => array('/user/profile'),
 
            # page after logout
            'returnLogoutUrl' => array('/user/login'),
        ),
	'message' => array(
            'userModel' => 'User',
            'getNameMethod' => 'getFullName',
            'getSuggestMethod' => 'getSuggest',
        ),
		
	),

	/*
 	 ********Componentes: User, Request, UrlManager, ErrorHandler********
 	 */
	'components'=>array(
	
		'request'=>array(
			'enableCsrfValidation'=>true,
			'enableCookieValidation'=>true,),
			
	
	
		'user'=>array(
		'class'=>'WebUser',
		  'loginUrl' => array('/user/login'),//modulo user
        'allowAutoLogin' => true,
      // enable cookie-based authentication
			
      //'identityClass' => 'app\models\User',
      //'identityCookie' => array(
      //    'name' => '_backendUser', // unique for backend
        //  'path'=>'/advanced/backend/web'  // correct path for the backend app.
      //),
 			
	  	),
  		
			
		
		// uncomment the following to enable URLs in path-format
		
		'urlManager'=>array(
			'urlFormat'=>'path',
			'rules'=>array(
				'post/<id:\d+>/<title:.*?>'=>'post/view',
				'posts/<tag:.*?>'=>'post/index',
				'<controller:\w+>/<action:\w+>'=>'<controller>/<action>',
			),
		),
		
		
		
		'errorHandler'=>array(
			// use 'site/error' action to display errors
			'errorAction'=>'error/error',
		),
		'mail' => array(
			'class' => 'ext.mail.YiiMail',
			'transportType' => 'smtp',
			'transportOptions'=>array(
							'host'=>'smtp.gmail.com',
							'encryption'=>'tls',
							'username'=>"pianosurfingapp@gmail.com",
			 				'password'=>"psapp2015",
							'port'=>465,
				),
			'viewPath' => 'application.views.mail',
			 'logging' => true,
			 'dryRun' => false
			 ),
			 'image'=>array(
            'class'=>'application.extensions.image.CImageComponent',
            // GD or ImageMagick
            'driver'=>'GD',
            // ImageMagick setup path
            /*'params'=>array('directory'=>'D:/Program Files/ImageMagick-6.4.8-Q16'),*/
      ),
	),

	
	 'params'=>array(
        'uploadPathPerfil'=>dirname(dirname(__FILE__)).'/../images/perfil/',
         'uploadPathPiano'=>dirname(dirname(__FILE__)).'/../images/pianos/',
      
    ),
	
	
);
