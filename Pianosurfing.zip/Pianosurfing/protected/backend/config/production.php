<?php
return CMap::mergeArray(
/*
 	 ********Este archivo es el complemento del main para la PRODUCCION*******
 	 */
	require(dirname(__FILE__).'/main.php'),
	array(
		
		'components'=>array(
			
		/*
 	 ********Componentes: Conexion a base de datos de produccion, Logging********
 	 */
		/*			'db'=>array(
				'connectionString' => 'mysql:host=labtdi.det.uvigo.es;dbname=pfc1',			
				'emulatePrepare' => true,
				'username' => 'abarbero',
				'password' => '2hmjk3',
				'charset' => 'utf8',
				'tablePrefix' => 'tbl_',
				),*/
	'db'=>array(
	
				'connectionString' => 'mysql:host=localhost;dbname=pianosurfing',
				'emulatePrepare' => true,
				'username' => 'ary',
				'password' => 'aryarycambiame',
				'charset' => 'utf8',
				'tablePrefix' => 'tbl_',
				),
		  'log'=>array(
			'class'=>'CLogRouter',
			'routes'=>array(
				array(
					'class'=>'CFileLogRoute',
					'levels'=>'error, warning, trace, info',
				),
				// uncomment the following to show log messages on web pages
				
				
				
			),
		),
			
	),
)
);
