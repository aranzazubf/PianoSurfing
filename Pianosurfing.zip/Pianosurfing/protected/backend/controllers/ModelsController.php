<?php

class ModelsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';
	private $_model;
	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('create','update','delete'),
				'users'=>UserModule::getAdmins(),
			),
			
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
			
	}


	public function actionCreate()
	{
		$model=new Models;

		if(isset($_POST['Models']))
		{
			$model->attributes=$_POST['Models'];
			if($model->save())
				$this->redirect(array('/confpianos/admin'));
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}

	public function actionUpdate()
	{
		$model=$this->loadModel();

			if(isset($_POST['Models']))
		{
			$model->attributes=$_POST['Models'];
			if($model->save())
					$this->redirect(array('/confpianos/admin'));
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	public function actionDelete()
	{
		$this->loadModel()->delete();

	
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('/confpianos/admin'));
	}

	public function loadModel()
	{
		if($this->_model===null)
		    {
		        if(isset($_GET['id']))
		        {
		            $condition='';
		            $this->_model=Models::model()->findByPk($_GET['id'], $condition);
		        }
		        if($this->_model===null)
		            throw new CHttpException(404,'The requested page does not exist.');
		    }
		    return $this->_model;
	}

		protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='models-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
