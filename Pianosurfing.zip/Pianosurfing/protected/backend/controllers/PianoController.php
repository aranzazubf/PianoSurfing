<?php

class PianoController extends GlobalBController
{
	public $layout='//layouts/column2';
	private $_model;
	public $params = array( 'pathImgPianos'=>'images/pianos/');

	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			//'postOnly + delete', // we only allow deletion via POST request
		);
	}

	
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','update','delete','admin','cargarbandera'),
				'users'=>UserModule::getAdmins(),
			),
			
			
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}





	public function actionIndex()
	{
		$conf=Confpianos::model()->findByAttributes(array('name'=>'piano_pag_max'));
		$piano_page_size=$conf->value;	

		$dataProvider=new CActiveDataProvider('Piano',array(
			
				
			'pagination'=>array(
				'pageSize'=>$this->NumPianosPag(),
			),
			));
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}
	
	public function actionView()
	{
	    $piano=$this->loadModel();
	    $this->render('view',array(
	        'model'=>$piano,
	    ));
	}
 
	public function actionUpdate()
	{
		$model=$this->loadModel();
		$this->performAjaxValidation($model);
		
		if(isset($_POST['cancel'])){
		$this->redirect(array('view','id'=>$model->id));
		}
		if(isset($_POST['Piano']))
		{
			$model->attributes=$_POST['Piano'];
  		//	$value = CUploadedFile::getInstance($model,'photo');
			if($model->save()){
  			//		$this->savePhotoPiano($model,$value,'update');
					$this->redirect(array('view','id'=>$model->id));
			}	
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}
 
		public function actionDelete()
		{
			$model=$this->loadModel();
		  	 $model->delete();
		   $this->redirect(array('mypianos'));
		
		}	 

	public function actionAdmin()
	{
		$model=new Piano('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Piano']))
			$model->attributes=$_GET['Piano'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}
public function actionCargarbandera()
		{
		
 
		if(isset($_POST['region_id'])){
				
			$country_id=(int)$_POST['region_id'];	
			
			$country=Country::model()->findByPk($country_id);
			
			$bandera=$country->isocode;
			$country_name=$country->country;
		
		
			echo CHtml::image(Yii::app()->request->baseUrl.'/images/banderas/24/'.$bandera.'.png','bandera');
					}
			else{
			echo '';			
			}
			}
		public function loadModel()
		{
		    if($this->_model===null)
		    {
		        if(isset($_GET['id']))
		        {
		            $condition='';
		            $this->_model=Piano::model()->findByPk($_GET['id'], $condition);
		        }
		        if($this->_model===null)
		            throw new CHttpException(404,'The requested page does not exist.');
		    }
		    return $this->_model;
		}




	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='piano-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
	public function NumPianosPag(){
		$conf=new Confpianos();
		$piano_page_size=$conf->getParam('piano_pag_max');	
		return $piano_page_size;
	}
	
	
	
	
	
	
	public function savePhotoPiano($model,$value,$action){
	
		if ($value) {
			if($action=='update'){
			$old_file = $model->photo;	
			if ($old_file&&file_exists($old_file))
					unlink($old_file);
			}
			$dir=$this->params['pathImgPianos'].$model->user_id.'/'.$model->id.'/';
			if (!file_exists($dir)) {
    			mkdir($dir, 0777, true);}
			$file_name= $dir.$model->id.'.'.$value->extensionName;
			$value->saveAs($file_name);
			$model->photo=$file_name;
			$model->save();
				}
	}
	
	
	
	
	
	
	
}
