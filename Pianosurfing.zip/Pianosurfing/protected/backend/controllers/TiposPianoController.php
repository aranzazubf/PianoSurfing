<?php

class TiposPianoController extends Controller
{
	
	public $layout='//layouts/column2';
	private $_model;
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}
	public function accessRules()
	{
		
			return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','create','update','admin','delete'),
				'users'=>UserModule::getAdmins(),
			),
			
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		
		);
	}

	public function actionCreate()
	{
		$model=new TiposPiano;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['TiposPiano']))
		{
			$model->attributes=$_POST['TiposPiano'];
			if($model->save())
					$this->redirect(array('/confpianos/admin'));
		}

		$this->render('create',array(
			'model'=>$model,
		));
	}


	public function actionUpdate($id)
	{
		$model=$this->loadModel();

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['TiposPiano']))
		{
			$model->attributes=$_POST['TiposPiano'];
			if($model->save())
					$this->redirect(array('/confpianos/admin'));
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}

	public function actionDelete()
	{
		$this->loadModel()->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('confpianos/admin'));
	}

		public function loadModel()
	{
		if($this->_model===null)
		    {
		        if(isset($_GET['id']))
		        {
		            $condition='';
		            $this->_model=TiposPiano::model()->findByPk($_GET['id'], $condition);
		        }
		        if($this->_model===null)
		            throw new CHttpException(404,'The requested page does not exist.');
		    }
		    return $this->_model;
	}

		protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='tipos-piano-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
