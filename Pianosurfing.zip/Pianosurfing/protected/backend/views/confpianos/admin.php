<div class="row" id="contact">
<div class="small-12 columns">
<h1 id="contact">
<?php echo Yii::t('piano', 'Configuration');?></h1>
<br/>

</div>
<div class="small-12 columns">
<h3><?php
echo Yii::t('piano', 'Configuration Parameters');?></h3>
</div>
<div class="small-12 columns">
<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'confpianos-grid',
	'dataProvider'=>$model->search(),
	'columns'=>array(
	'name',
	'value',
	array(
			'class'=>'CButtonColumn',
			//'template'=>'{update} {delete}',
         'template'=>'{update}',
       ),
	),
)); ?>
</div>
<div class="small-12 columns">
<h3><?php
echo Yii::t('piano',"Piano's Types");?></h3>
<?php $this->renderPartial('/tiposPiano/_admin',array(
	'model'=>TiposPiano::model(),
)); ?>
</div>
<div class="small-12 columns">
<h2><?php
echo Yii::t('piano',"Piano's Marcas");?></h2>
</div>
<div class="small-12 columns">
<?php $this->renderPartial('/marca/_admin',array(
	'model'=>Marca::model(),
)); ?>
</div></div>
