<div class="row" id="contact">
<div class="small-12 columns">
<h1 id="contact"> <?php echo Yii::t('piano','Edit');?></h1>
</div>

<div class="small-12 columns">
<?php $this->renderPartial('_form', array('model'=>$model)); ?>
</div>
</div>