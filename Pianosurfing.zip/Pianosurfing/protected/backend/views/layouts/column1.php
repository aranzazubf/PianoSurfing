<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/main'); ?>
<div id="content">
	<?php echo $content; ?>
<!-- content -->
<?php $this->endContent(); ?>
</div></div>