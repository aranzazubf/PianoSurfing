<?php /* @var $this Controller */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="language" content="en" />	
   <link rel="stylesheet" href="<?php echo Yii::app()->request->baseUrl;?>/css/foundation.css" />
	<title><?php echo CHtml::encode($this->pageTitle); ?></title>

	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/app_foundation.css" />
  	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/landingpage.css" />
   <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
   <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/todos.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/main.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/admin.css" />
	</head>

<body>
 <script src="<?php echo Yii::app()->request->baseUrl;?>/js/vendor/modernizr.js"></script>
<!-- *****************************************CABECERA inicio***************************** -->

<div  id="cabecera">
		<div class="row" id="cabecera_main">
   	  	 <div class="small-2 columns">
   	
   	  	 <img id="logomain" src="<?php echo Yii::app()->request->baseUrl;?>/images/diseno/Logo.png">
   	  	 </div>  
       	 <div class="small-10 columns">
          <div id="landingmainmenu">
		          <ul id="menusuperior"><li>
					<?php $this->widget('ext.LangPick.ELangPick', array(
							//'buttonsSize' => 'mini',                // mini, small, large
		    				//'buttonsColor' => 'success',            // primary, info, success, warning, danger, inverse 
							'pickerType' => 'dropdown',              // buttons, links, dropdown
							 //'excludeFromList' => array('pl', 'en'), // list of languages to exclude from list
		    				//'linksSeparator' => '<b> | </b>',   // if picker type is set to 'links'
		    'id'=>'langpick',)	);?>
		    		</li></ul>  
					<?php $this->widget('zii.widgets.CMenu',array(
  					'items'=>array(
					array('itemOptions'=>array('id' => 'menu'),'url'=>Yii::app()->getModule('user')->loginUrl, 'label'=>Yii::t('menu',"Login"), 'visible'=>Yii::app()->user->isGuest),
					array('itemOptions'=>array('id' => 'menu'),'url'=>Yii::app()->getModule('user')->profileUrl, 'label'=>Yii::t('menu',"Profile"), 'visible'=>!Yii::app()->user->isGuest),
					array('itemOptions'=>array('id' => 'menu'),'url'=>array('/user/admin'), 'label'=>Yii::t('menu','Users'), 'visible'=>!Yii::app()->user->isGuest),
					array('itemOptions'=>array('id' => 'menu'),'url'=>Yii::app()->getModule('user')->profilefieldUrl, 'label'=>Yii::t('menu',"Profile Fields"), 'visible'=>!Yii::app()->user->isGuest),
					array('itemOptions'=>array('id' => 'menu'),'url'=>array('/piano/admin'), 'label'=>Yii::t('menu','Pianos'), 'visible'=>!Yii::app()->user->isGuest),
					array('itemOptions'=>array('id' => 'menu'),'url'=>array('/confpianos/admin'), 'label'=>Yii::t('menu','Configuration'),'visible'=>!Yii::app()->user->isGuest),					
					array('itemOptions'=>array('id' => 'menu'),'url' => Yii::app()->getModule('message')->inboxUrl,'label'=>Yii::t('menu','Messages').(Yii::app()->getModule('message')->getCountUnreadedMessages(Yii::app()->user->getId()) ?
            		' (' . Yii::app()->getModule('message')->getCountUnreadedMessages(Yii::app()->user->getId()) . ')' : ''),'visible' => !Yii::app()->user->isGuest),

				
					array('itemOptions'=>array('id' => 'menu'),'url'=>Yii::app()->getModule('user')->logoutUrl, 'label'=>Yii::t('menu',"Logout").' ('.Yii::app()->user->name.')', 'visible'=>!Yii::app()->user->isGuest),
					),
					'id'=>'menusuperior',
							)); ?>
			 </div>
          </div>
		</div>
</div>
<!-- *****************************************CABECERA FIN***************************** -->
<!-- *****************************************CONTENIDO INICIO***************************** -->
<div id="contenido">
<?php echo $content; ?>
</div>
<!-- *****************************************CONTENIDO FIN***************************** -->
<div class="clear"></div>

<!-- *****************************************FOOTER INICIO***************************** -->
	<?php /************************FOOTER con 4 columnas************************/?> 
	
 <div id="footer" class="footer"><div class="row">
        	 <div class="small-6 columns">
     <img id="logo" src="<?php echo Yii::app()->request->baseUrl;?>/images/diseno/Footer/Logo.png"> </div>   
       	 <div class="small-6 columns" id="redes">
       	   <a target="_blank" ng-href="https://www.twitter.com/" href="https://www.twitter.com">  <img id="logoredes" src="<?php echo Yii::app()->request->baseUrl;?>/images/diseno/Footer/twitter.png"></a>
    <a target="_blank" ng-href="https://www.facebook.com/" href="https://www.facebook.com"> <img id="logoredes" src="<?php echo Yii::app()->request->baseUrl;?>/images/diseno/Footer/facebook.png"></a>
</div>  
</div></div>

</body>
</html>