<?php
/* @var $this MarcaController */
/* @var $model Marca */



?>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'marca-grid',
	'dataProvider'=>$model->search(),
	
	'columns'=>array(
		
		'name',
		array(
			'class'=>'CButtonColumn',
			'template'=>'{update} {create} {delete}',
         'buttons'=>array (
             'update'=> array(
                'url'=>'Yii::app()->createUrl("marca/update", array("id"=>$data->id))',),
        		 'create'=>array(
        		 		 'label'=>Yii::t('piano','New'),   
        		     'imageUrl'=>Yii::app()->request->baseUrl.'/images/configuracion/add.png',
            	 'url'=>'Yii::app()->createUrl("marca/create")',),
        		 'delete'=>array(
                'url'=>'Yii::app()->createUrl("marca/delete", array("id"=>$data->id))',),
          ),
       ),
	),
)); ?>
