<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'marca-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>
	<p class="note"><?php echo Yii::t('piano','Fields with')?> <span class="required">*</span> <?php echo Yii::t('piano','are required.')?></p>
	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'name'); ?>
		<?php echo $form->textField($model,'name',array('size'=>60,'maxlength'=>255)); ?>
		<?php echo $form->error($model,'name'); ?>
	</div>

	<div class="row">
  <div class="small-6 small-centered columns">
		 <button type="submit" class="medium button green"><?php echo  $model->isNewRecord ? Yii::t('piano','Create' ):  Yii::t('piano','Save') ?></button>
	</div></div>
<?php $this->endWidget(); ?>

</div><!-- form -->