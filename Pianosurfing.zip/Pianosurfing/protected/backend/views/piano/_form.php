<?php  
$assetsCss=dirname(__FILE__).'/../../../css';
  $cs = Yii::app()->clientScript;
  $cs->registerScriptFile("https://maps.googleapis.com/maps/api/js?v=3.exp");

    $cs->registerCssFile(Yii::app()->request->baseUrl.'/css/bootstrap.min.css');
  $cs->registerScriptFile(Yii::app()->request->baseUrl.'/css/js/bootstrap.min.js');
    $cs->registerScriptFile(Yii::app()->assetManager->publish(Yii::getPathOfALias("application.assets.piano.form.js").'/geocoder.js'));
?>

<div class="form">
<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'piano-form',
	'enableClientValidation'=>true,
//'clientOptions'=>array( 'validateOnSubmit'=>true, ),
	//'enableAjaxValidation'=>true,
	'htmlOptions' => array('enctype'=>'multipart/form-data'),
)); ?>


<div class="small-12 columns">
<div class="small-9 small-centered columns">
<h2 id="galeria"><?php echo Yii::t('piano','Piano Gallery');?></h2>
	<?php
	if ($model->galleryBehavior->getGallery() === null) {?>
		<label class="galeria"><?php
	    echo Yii::t('piano','Before add photos to product gallery, you need to save your piano');
?></label> 
<?php
	}
	else {
			
 
   $this->widget('GalleryManager', array(
	        'gallery' => $model->galleryBehavior->getGallery(),
	        'controllerRoute' => '/gallery', //route to gallery controller
	    'id'=>'gallerywidget',));
   
	}
	?>
</div>
</div>
<div class="row">
<div class="small-12 columns">
<p id="text_contact" class="note"><?php echo Yii::t('piano','Fields with')?> <span class="required">*</span> <?php echo Yii::t('piano','are required.')?></p>
</div>
<?php echo $form->errorSummary($model); ?>
</div>

<div class="row">
<div class="small-3 columns">
<?php echo $form->labelEx($model,'category'); ?>
		<?php echo $form->dropDownList($model,'category',TiposPiano::items()); ?>
		<?php echo $form->error($model,'category'); ?>

</div>
<div class="small-3 columns">

<?php echo $form->labelEx($model,'marca'); ?>
  		<?php echo $form->dropDownList($model,'marca',Marca::items()); ?> 		
		<?php echo $form->error($model,'marca'); ?>

</div>
<div class="small-3 columns">
<?php echo $form->labelEx($model,'model'); ?>
		<?php echo $form->textField($model,'model',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'model'); ?>

</div>

<div class="small-3 columns">
<div class="small-6 columns">
<?php echo $form->labelEx($model,'year'); ?>
		<?php echo $form->textField($model,'year',array('size'=>4,'maxlength'=>4)); ?>
		<?php echo $form->error($model,'year'); ?>
		</div>
<div class="small-6 columns">
<?php echo $form->labelEx($model,'conservation'); ?>
		<?php echo $form->textField($model,'conservation',array('placeholder'=>Yii::t('piano',' 1 to 10'))); ?>
		<?php echo $form->error($model,'conservation'); ?>
</div>
</div>
</div>
<div class="row">
<div class="small-6 columns">
		<?php echo $form->labelEx($model,'disponibility'); ?>
		<?php echo $form->textArea($model,'disponibility',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'disponibility'); ?>
</div>
<div class="small-6 columns">

		<?php echo $form->labelEx($model,'instrument_description'); ?>
		<?php echo $form->textArea($model,'instrument_description',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'instrument_description'); ?>
</div>
</div>


<div class="row">
<div class="small-6 columns">
	<div class="row">
		<div class="small-10 columns">
		<?php echo $form->labelEx($model,'country_id'); ?>
		<?php echo $form->dropDownList($model,'country_id',Country::items(),
			 array(
			 'id'=>'country_id',
    			//'prompt'=>Yii::t('piano','Select a Country'),------QUE HACEMOS PARA QUE NO DE ERROR Y SE MUESTRE ESTE POR DEFECTO*/
    			'ajax' => array('type'=>'POST', 
   					  'url' => CController::createUrl('cargarbandera'), 
    					  'update' => '#bandera_country_id',
  						  'data'=>array('region_id'=>'js:this.value'),
  					
  				))); 
			
		?>
		<?php echo $form->error($model,'country_id'); ?>
		</div>
		<div class="small-2 columns">
		<div  id="bandera_country_id"><?php 	echo CHtml::image(Yii::app()->request->baseUrl.'/images/banderas/24/'.$model->piano_country_id->isocode.'.png','bandera',array("id"=>"bandera_country_id"));?></div>
  		</div>
  	</div>
  	<div class="row">
	<div class="small-6 columns">
		<?php echo $form->labelEx($model,'city'); ?>
		<?php echo $form->textField($model,'city',array('size'=>60,'maxlength'=>255, 'id'=>'city',)); ?>
		<?php echo $form->error($model,'city'); ?>
		</div>
	<div class="small-6 columns">
		<?php echo $form->labelEx($model,'postal_code'); ?>
		<?php echo $form->textField($model,'postal_code', array('id'=>'postal_code')); ?>
		<?php echo $form->error($model,'postal_code'); ?>
	</div>
	</div>
	<div class="row">
	 <div class="small-12 columns">
		<?php echo $form->labelEx($model,'address'); ?>
		<?php echo $form->textArea($model,'address',array('id'=>'address')); ?>
		<?php echo $form->error($model,'address'); ?>
	</div>
	</div>
	<div class="row">
	<div class="small-6 small-centered columns">
	<input type="button" class="medium button green" id="location" value="<?php echo Yii::t('piano','Check location');?>" onclick="codeAddress()">
	</div>
  </div>
</div>
<div class="small-6 columns">
	<div class="row">
	<div class="small-12 columns">
	<?php 
	$this->renderPartial('mapa', array('model'=>$model)); 
	?>
	</div>
	</div>
</div>
<div class="row buttons">
<div class="small-12 columns">
<div class="small-6 columns">
        <button type="submit" id="save" class="medium button green"><?php echo $model->isNewRecord ? Yii::t('piano','Create' ): Yii::t('piano','Save'); ?>
			</button></div>
<div class="small-6  columns">
	     <button type="submit" id "cancel" class="medium button green" name="cancel"><?php echo Yii::t('piano','Cancel'); ?>
</button></div>	
	</div>
	
	</div>
		
		<?php echo $form->hiddenField($model,'latitude',array('id'=>'latitude')); ?>
		<?php echo $form->error($model,'latitude'); ?>

		<?php echo $form->hiddenField($model,'longitude',array('id'=>'longitude')); ?>
		<?php echo $form->error($model,'longitude'); ?>
	
  </div>
<?php $this->endWidget(); ?></div>
	<!-- form -->