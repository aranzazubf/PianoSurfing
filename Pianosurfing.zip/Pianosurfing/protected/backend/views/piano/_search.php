<?php
/* @var $this PianoController */
/* @var $model Piano */
/* @var $form CActiveForm */
?>
<div class="small-12 columns">
<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'user_search'); ?>
		<?php echo $form->textArea($model,'user_search',array('rows'=>6, 'cols'=>50)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'disponibility'); ?>
		<?php echo $form->textArea($model,'disponibility',array('rows'=>6, 'cols'=>50)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'category'); ?>
 
		<?php echo $form->dropDownList($model,'category',TiposPiano::items()); ?> 
		
	</div>
	<div class="row">
			<?php echo $form->label($model,'marca'); ?>
  <?php echo $form->dropDownList($model,'marca',Marca::items()); ?> 		
	</div>

	<div class="row">
		<?php echo $form->label($model,'model'); ?>
		<?php echo $form->textArea($model,'model',array('rows'=>6, 'cols'=>50)); ?>
	</div>

		<div class="row">
		<?php echo $form->labelEx($model,'instrument_description'); ?>
		<?php echo $form->textArea($model,'instrument_description',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'instrument_description'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'year'); ?>
		<?php echo $form->textField($model,'year',array('size'=>4,'maxlength'=>4)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'conservation'); ?>
		<?php echo $form->textField($model,'conservation'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'postal_code'); ?>
		<?php echo $form->textField($model,'postal_code'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'city'); ?>
		<?php echo $form->textField($model,'city',array('size'=>60,'maxlength'=>255)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'country_id'); ?>
		<?php echo $form->textField($model,'country_id',Country::items()); ?>
	</div>
	 <div class="row">
        <?php echo $form->label($model,'statuspiano'); ?>
        <?php echo $form->dropDownList($model,'statuspiano',Piano::itemAlias('PianoStatus')); ?>
    </div>
<?php /*
	<div class="row">
		<?php echo $form->label($model,'create_time'); ?>
		<?php echo $form->textField($model,'create_time'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'update_time'); ?>
		<?php echo $form->textField($model,'update_time'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'country_id'); ?>
		<?php echo $form->textField($model,'country_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'user_id'); ?>
		<?php echo $form->textField($model,'user_id'); ?>
	</div>
<div class="row">
		<?php echo $form->label($model,'id'); ?>
		<?php echo $form->textField($model,'id'); ?>
	</div>
	*/?>
	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form --></div>