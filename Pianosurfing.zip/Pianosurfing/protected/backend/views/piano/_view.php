<?php
/* @var $this PianoController */
/* @var $data Piano */
?>


<div class="view">
	<?php 
	if($data->user_id==Yii::app()->user->id){?>
	<b><?php echo CHtml::encode($data->getAttributeLabel(Yii::t('piano','Update'))); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('update', 'id'=>$data->id)); ?>
	<br />
	<b><?php echo CHtml::link(Yii::t('piano','Delete'),array('delete', 'id'=>$data->id),array('confirm'=>'Are you sure you want to delete this item?') ); ?>:</b>
	<br />
		<?php }
	?>
	
<br />
<?php /*Pondermos un link a el perfil del usuario... o solo cuando haya compartido con este usuario... o se le
manda una especie de solicitud de amistad y cuando acepte, este le permite ver su perfil?*/?>
	<b><?php echo CHtml::encode($data->getAttributeLabel('user_search')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->user->username),array('/user/user/view/', 'id'=>$data->user->id)); ?>
	<br />
	<b><?php echo CHtml::encode($data->getAttributeLabel('disponibility')); ?>:</b>
	<?php echo CHtml::encode($data->disponibility); ?>
	<br />
   
   <b><?php echo CHtml::encode($data->getAttributeLabel('category')); ?>:</b>
	<?php echo CHtml::encode(TiposPiano::item($data->category)); ?>
	<br />
	
	<b><?php echo CHtml::encode($data->getAttributeLabel('marca')); ?>:</b>
	<?php echo CHtml::encode(Marca::item($data->marca)); ?>
	<br />
	
<b><?php echo CHtml::encode($data->getAttributeLabel('model')); ?>:</b>
	<?php echo CHtml::encode($data->model); ?>
	<br />
	
	<b><?php echo CHtml::encode($data->getAttributeLabel('instrument_description')); ?>:</b>
	<?php echo CHtml::encode($data->instrument_description); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('year')); ?>:</b>
	<?php echo CHtml::encode($data->year); ?>
	<br />

	
	<b><?php echo CHtml::encode($data->getAttributeLabel('conservation')); ?>:</b>
	<?php echo CHtml::encode($data->conservation); ?>
	<br />
<b><?php echo CHtml::encode($data->getAttributeLabel('country_id')); ?>:</b>
	<?php echo CHtml::encode(Country::item($data->country_id)); ?>
	<br />
	

	<b><?php echo CHtml::encode($data->getAttributeLabel('city')); ?>:</b>
	<?php echo CHtml::encode($data->city); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('postal_code')); ?>:</b>
	<?php echo CHtml::encode($data->postal_code); ?>
	<br />
	<b><?php echo CHtml::encode($data->getAttributeLabel('address')); ?>:</b>
	<?php echo CHtml::encode($data->address); ?>
	<br />

</div>