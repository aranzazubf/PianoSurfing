<?php
/* @var $this PianoController */
/* @var $data Piano */
?>
<?php /*Pondermos un link a el perfil del usuario... o solo cuando haya compartido con este usuario... o se le
manda una especie de solicitud de amistad y cuando acepte, este le permite ver su perfil?*/?>

<hr id="lista">
<div class="small-12 columns">
<div class="small-4 columns">
<img id="foto_piano" src="<?php echo $this->muestraFotoPiano($data);?>">
</div>
<div class="small-8 columns"> 
	<div class="row" id="perfil">
		<div class="small-2 columns">
		<img  id="foto_perfil" src="<?php echo Yii::app()->request->baseUrl.'/'.$data->user->profile->foto;?>">
		</div>
		<div class="small-10 columns">
		
	
		<div class="row">
		<label class="viewlista" id="nombre"><?php echo CHtml::link(CHtml::encode($data->user->username),array('/user/user/view/', 'id'=>$data->user->id),array('class'=>'link_usuario','id'=>'link_usuario',));?></label> 

		
		</div>
		<div class="row" id="edad">
		<label class="viewlista"><?php echo CHtml::encode($data->user->profile->birth); ?></label>

		</div>

		</div>
						
	</div>
	<div class="row" id="minibiografia">
	<div class="small-12 columns">
	<label ><?php echo CHtml::encode($data->user->profile->biography); ?></label>
	</div>
	</div>
	<div class="row" id="datospiano">
<label class="viewlista2">
<?php echo CHtml::encode(Marca::item($data->marca)); ?>	|
<?php echo CHtml::encode(TiposPiano::item($data->category)); ?>	|
<?php echo CHtml::encode($data->year); ?>		|	
<?php echo Yii::t('piano','status');?>:<?php echo CHtml::encode($data->conservation); ?>/10	|
<?php echo CHtml::encode($data->piano_country_id->country);?>		
</label>	

	
	</div>
		
<div class="row">
<label class="viewlistaop"><b><?php echo CHtml::link(Yii::t('piano','View'),array('view', 'id'=>$data->id),array('class'=>'link_operations', 'id'=>'link_operations') ); ?></b>
<?php 
	if($data->user_id==Yii::app()->user->id){?>
	<b><?php echo CHtml::link( CHtml::encode($data->getAttributeLabel(Yii::t('piano','Update'))), array('update', 'id'=>$data->id),array('class'=>'link_operations','id'=>'link_operations2')); ?></b>
   <b><?php echo CHtml::link(Yii::t('piano','Delete'),array('delete', 'id'=>$data->id),array('confirm'=>'Are you sure you want to delete this item?','class'=>'link_operations','id'=>'link_operations3') ); ?></b>
		<?php }
	?>	</label>
	</div>
</div>
</div>

