<?php


Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#piano-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>
<div class="row" id="contact">
<div class="small-12 columns">
<h1 id="contact">
<?php
echo Yii::t('piano','Manage Pianos');
?></h1>
<br/>

</div>
<div class="small-12 columns">
<p>
<?php
 echo Yii::t('piano',"You may optionally enter a comparison operator (<b>&lt;</b>, <b>&lt;=</b>, <b>&gt;</b>, <b>&gt;=</b>, <b>&lt;&gt;</b> or <b>=</b>) at the beginning of each of your search values to specify how the comparison should be done."); 
 ?>
</p>
</div>
<div class="small-12 columns">
<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->
</div>
<div class="small-12 columns">
<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'piano-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'id',
		array(
   		'name'=>'user_search',
   		'value' => '$data->user->username',
		),
		'disponibility',
	
	  array(               
            'name'=>'category',
            'value'=>'TiposPiano::item($data->category)',
            'filter'=>TiposPiano::items(),
        ),
	 array(               
          'name'=>'marca',
          'value'=>'Marca::item($data->marca)',
			 'filter'=>Marca::items(),
          
        ),
		
		'model',
		'instrument_description',
	
		
		'year',
		'conservation',
		'postal_code',
		'city',
			array(
			'name'=>'country_id',
			'value'=>'Country::item($data->country_id)',
			'filter' => Country::items(),),
			array(
			'name'=>'statuspiano',
			'value'=>'Piano::itemAlias("PianoStatus",$data->statuspiano)',
			'filter' => Piano::itemAlias("PianoStatus"),
		),
		/*
		'create_time',
		'update_time',
		'country_id',
		'user_id',
		*/
		array(
			'class'=>'CButtonColumn',
			'id'=>'piano',
		),
	),
)); ?>
</div></div>
