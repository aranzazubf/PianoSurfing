
<?php
/* @var $this PianoController */
/* @var $model Piano */

$this->breadcrumbs=array(
	'Pianos'=>array('index'),
	$model->id,
);

$this->menu=array(
	array('label'=>Yii::t('piano','List Piano'), 'url'=>array('index')),
	array('label'=>Yii::t('piano','Create Piano'), 'url'=>array('create')),
	array('label'=>Yii::t('piano','Update Piano'), 'url'=>array('update', 'id'=>$model->id),'view'=>Yii::app()->user->id==$model->user_id),
	array('label'=>Yii::t('piano','Delete Piano'), 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?'),'view'=>Yii::app()->user->id==$model->user_id),
		array('label'=>Yii::t('piano','Gallery Piano'), 'url'=>array('galeria', 'id'=>$model->id)),

);
?>


<h2>Product galley</h2>
	<?php
 
   $this->widget('GalleryManager', array(
	        'gallery' => $model->galleryBehavior->getGallery(),
	        'controllerRoute' => '/gallery', //route to gallery controller
	    ));
	    ?>