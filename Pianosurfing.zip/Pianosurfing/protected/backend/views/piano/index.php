<script>
var token= "<?php echo Yii::app()->request->csrfToken;?>";

</script>
<?php  
$assetsCss=dirname(__FILE__).'/../../../css';
  $cs = Yii::app()->clientScript;
  $cs->registerScriptFile("https://maps.googleapis.com/maps/api/js?v=3.exp");
  $cs->registerScriptFile(Yii::app()->assetManager->publish(Yii::getPathOfALias("application.assets.piano.index.js").'/locationpianos.js'));
?>
	
<div class="row" id="indexsup">
		<div class="row" id="indexrow1">
			<div class="small-9 columns">
			<div class="row" id="busqueda">
   	   		<div class="small-10 columns" id="cuadrobusquedaindex">
						<?php echo CHtml::form(Yii::app()->createUrl('piano/index'),'post') ?>
			  			<div class="small-10 columns"id="cuadrobusquedaindexa">
						
        					<?php	 
        						$this->widget('zii.widgets.jui.CJuiAutoComplete', array(
				      			'model'=>'Country',
				      			'name'=>'name',
				     				'attribute'=>'country',
				      			'source'=>$this->createUrl('site/suggestCountry'),
				      			 'options'=> array(
				      			'showAnim'=>'fold',
				      			'size'=>'30',
				      			'minLength'=>'3', // Minimo de caracteres que hay que digitar antes de relizar la busqueda
				 					'select'=>"js:function(event, ui) {
				           	 		$('#country_search').val(ui.item.id);
				           
				       			 }",),
				      			 'htmlOptions'=> array('placeholder'=>Yii::t('landingpage','Which country do you going to travell to?'),'id'=>'autocomplete',
				  						)));?>
        	 				</div>
        					<input id="country_search" name="country_search" type="hidden" style="width: 300px; margin-bottom: 5px">
      				<div class="small-2 columns"id="cuadrobusquedaindexb">
         		 	 <div class="button postfix">  
         	  		 <a href="#" id="go" onClick="document.forms[0].submit();return false;">  <?php echo Yii::t('landingpage','GO'); ?></a>
         	  		</div>
         	  		</div>
         	  		<?php echo CHtml::endForm() ?>
	       </div>
		</div>
		</div>
		</div>
		<div class="row" id="indexrow2">
		<div class="small-12 columns" id="mapa">
			<div id="map-canvas" style="width:auto;height:250px;"></div>
				<input type="hidden" id='latitude' name='latitude'>
				<input type="hidden" id='longitude' name='longitude'>
			
		</div>
		</div>
</div>















<?php if(Yii::app()->getController()->getAction()->getId()=='mypianos'){?>
<div class="row" id="create_piano">
<div class="small-8 small-centered columns">
<div class="small-6 columns">
        <button type="submit" id="create" class="medium button green" onclick = 'js:document.location.href="create"'><?php echo Yii::t('piano','Create Piano' ); ?>
			</button></div>
</div></div><?php }?>















<div class="row" id="indexinf">
<div class="small-12 columns">
<div class="small-9 columns">
<div class="row" id="pianolocation">
<div class="small-6 columns">
<label id="titulo_pianos">
   <?php if($country!="") echo "Your Piano in"; ?>
 <?php echo $country?>
</label>
</div>
</div>
<?php if($count>0){?>
<div class="row" id="itemlista">

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
  'enablePagination'=>false,
   'summaryText'=>"",
	'itemView'=>'_viewlista',
	'id'=>'lista',
)); ?>
</div>
<?php }?>
<hr id="lista">
<?php if($count>0){?>
<div class="small-12 columns">
 <?php 
   $this->widget('CLinkPager', array(
	'header' => '',
	'firstPageLabel' => '',
	'prevPageLabel' => '&lt;',
	'nextPageLabel' => '&gt;',
	'lastPageLabel' => '',
	'pages' => $dataProvider->pagination,
	'id'=>'pager',
));
    ?></div>
<?php }?>
</div>
<div class="small-3 columns" id="banners_listapianos">
<div class="row" id="indexbanner1"><img id="banner2" src='<?php echo Yii::app()->request->baseUrl;?>/images/diseno/banners_pianos/Anunciate.jpg'>
</div>
<div class="row" id="indexbanner1"><img id="banner2" src='<?php echo Yii::app()->request->baseUrl;?>/images/diseno/banners_pianos/bancsabadell.png'>
</div>
<div class="row" id="indexbanner1"><img id="banner2" src='<?php echo Yii::app()->request->baseUrl;?>/images/diseno/banners_pianos/IKFMEII.png'>
</div>
</div>
</div>

</div>


