<?php /* @var $this Controller */ ?>
<div id="map-canvas"
 style="width: auto;
  height: 256px;"></div>

