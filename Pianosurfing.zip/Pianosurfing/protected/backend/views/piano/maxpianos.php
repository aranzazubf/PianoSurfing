<div class="row" id="contact">
<div class="small-12 columns">

<?php if(Yii::app()->user->hasFlash('create')): ?>
<div class="success">
	<?php echo Yii::app()->user->getFlash('create'); ?>
</div>
<?php else: ?>
<?php endif; ?>
</div>

</div>
</div>
