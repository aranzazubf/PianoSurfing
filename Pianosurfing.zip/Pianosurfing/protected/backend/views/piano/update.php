<?php
/* @var $this PianoController */
/* @var $model Piano 

$this->breadcrumbs=array(
Yii::t('piano','Pianos')=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	Yii::t('piano','Update'),
);

$this->menu=array(
	array('label'=>Yii::t('piano','List Piano'), 'url'=>array('index')),
	array('label'=>Yii::t('piano','Create Piano'), 'url'=>array('create')),
	array('label'=>Yii::t('piano','View Piano'), 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>Yii::t('piano','Gallery Piano'), 'url'=>array('galeria', 'id'=>$model->id)),
);*/

?>


<div class="row" id="contact">
<div class="small-12 columns">
<div class="row" id="contact_title">
<h1 id="contact"><?php echo Yii::t('piano','Update Piano')?>, <?php echo $model->id; ?></h1>
</div>
</div>
<?php $this->renderPartial('_form', array('model'=>$model)); ?>
</div>