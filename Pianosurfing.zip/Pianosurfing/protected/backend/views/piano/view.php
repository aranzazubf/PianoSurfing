<?php  
  $cs = Yii::app()->clientScript;
  $cs->registerCssFile(Yii::app()->request->baseUrl.'/css/bootstrap.min.css');
  $cs->registerScriptFile(Yii::app()->request->baseUrl.'/css/js/bootstrap.min.js');
?>
<div class="row">
<div class="small-12 columns">
<h1 id="contact"><?php echo Yii::t('piano','Your Piano'); ?></h1></div></div>
<div class="row" id="contact">
<div class="small-6 columns">
	<div class="row" id="perfil">
		<div class="small-2 columns">
		<img  id="foto_perfil" src="<?php echo Yii::app()->request->baseUrl.'/'.$model->user->profile->foto;?>">
		</div>
		<div class="small-10 columns">
		<div class="row">
		<label class="viewlista" id="nombre"><?php echo CHtml::link(CHtml::encode($model->user->username),array('/user/user/view/', 'id'=>$model->user->id),array('class'=>'link_usuario','id'=>'link_usuario',));?></label> 
		</div>
		<div class="row" id="edad">
		<label class="viewlista"><?php echo CHtml::encode($model->user->profile->birth); ?></label>
		</div>
		</div>
		</div>
	<div class="row" id="minibiografia">
	<div class="small-12 columns">
	<label ><?php echo CHtml::encode($model->instrument_description); ?></label>
	</div>
	</div>
	<div class="row" id="datospiano">
	<label class="viewlista2">
		<?php echo CHtml::encode(Marca::item($model->marca)); ?>	|
		<?php echo CHtml::encode($model->model); ?>		|
		<?php echo CHtml::encode(TiposPiano::item($model->category)); ?>	|
		<?php echo CHtml::encode($model->year); ?>		|	
		<?php echo Yii::t('piano','status');?>:<?php echo CHtml::encode($model->conservation); ?>/10	|
<?php echo CHtml::encode($model->piano_country_id->country);?>	|
		<?php echo CHtml::encode($model->city);?> |
		<?php echo CHtml::encode($model->postal_code);?> |
		<?php echo CHtml::encode($model->disponibility);?> 
	</label>	
	</div>
		<?php 
	if($model->user_id==Yii::app()->user->id){?>
	<div class="row">
		<label class="viewlistaop"><b><?php echo CHtml::link( CHtml::encode($model->getAttributeLabel(Yii::t('piano','Update'))), array('update', 'id'=>$model->id),array('class'=>'link_operations','id'=>'link_usuario2',)); ?></b>
		<b><?php echo CHtml::link(Yii::t('piano','Delete'),array('delete', 'id'=>$model->id),array('confirm'=>'Are you sure you want to delete this item?','class'=>'link_operations','id'=>'link_usuario2',) ); ?></b></label>
	</div>
		<?php }
	?>	
	</div>


	<div class="small-6 columns">
	<?php
	if ($model->galleryBehavior->getGallery() === null) {?>
	<label class="galeria"><?php
	    echo Yii::t('piano','Before add photos to product gallery, you need to save your piano');
?></label> 
<?php
	}
	else {
			
 if($model->isOwner())
   $this->widget('GalleryManager', array(
	        'gallery' => $model->galleryBehavior->getGallery(),
	        'controllerRoute' => '/gallery', //route to gallery controller
	        'id'=>'gallery_manager',
	    ));
	   else{
			  
	   $fotos=$model->getGalleryPhotos();
	   if($fotos){?>
 <div class="sorter">	   
	   <?php 
	   foreach($fotos as $foto){?>
	    
	     <div class="foto">	
	     <img  id="foto_piano" src="<?php echo $foto->getPreview();?>">
	     </div>
	   <?php 
	   }
	   ?></div><?php
	   }
	   
	   }


	}
	?></div>
	</div>
