<?php
/* @var $this TiposMessageController */
/* @var $model TiposMessage */

$this->breadcrumbs=array(
	'Tipos Messages'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List TiposMessage', 'url'=>array('index')),
	array('label'=>'Manage TiposMessage', 'url'=>array('admin')),
);
?>

<h1>Create TiposMessage</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>