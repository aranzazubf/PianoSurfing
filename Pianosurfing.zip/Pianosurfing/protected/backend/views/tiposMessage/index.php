<?php
/* @var $this TiposMessageController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Tipos Messages',
);

$this->menu=array(
	array('label'=>'Create TiposMessage', 'url'=>array('create')),
	array('label'=>'Manage TiposMessage', 'url'=>array('admin')),
);
?>

<h1>Tipos Messages</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
