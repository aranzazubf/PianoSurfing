<?php
/* @var $this TiposMessageController */
/* @var $model TiposMessage */

$this->breadcrumbs=array(
	'Tipos Messages'=>array('index'),
	$model->name=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List TiposMessage', 'url'=>array('index')),
	array('label'=>'Create TiposMessage', 'url'=>array('create')),
	array('label'=>'View TiposMessage', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage TiposMessage', 'url'=>array('admin')),
);
?>

<h1>Update TiposMessage <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>