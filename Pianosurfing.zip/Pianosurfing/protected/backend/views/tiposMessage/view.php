<?php
/* @var $this TiposMessageController */
/* @var $model TiposMessage */

$this->breadcrumbs=array(
	'Tipos Messages'=>array('index'),
	$model->name,
);

$this->menu=array(
	array('label'=>'List TiposMessage', 'url'=>array('index')),
	array('label'=>'Create TiposMessage', 'url'=>array('create')),
	array('label'=>'Update TiposMessage', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Delete TiposMessage', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage TiposMessage', 'url'=>array('admin')),
);
?>

<h1>View TiposMessage #<?php echo $model->id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'id',
		'name',
		'code',
		'type',
		'position',
	),
)); ?>
