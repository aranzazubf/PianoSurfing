<?php
/* @var $this TiposPianoController */
/* @var $model TiposPiano */


?>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'tipos-piano-grid',
	'dataProvider'=>$model->search(),
	
	'columns'=>array(
		
		array('name'=>'name',
		//'value'=>Yii::t('piano',$model->name)),
			'value'=>'Yii::t("piano",$data->name)'),
	array(
			'class'=>'CButtonColumn',
			'template'=>'{update} {create} {delete}',
         'buttons'=>array (
             'update'=> array(
                'url'=>'Yii::app()->createUrl("tiposPiano/update", array("id"=>$data->id))',),
        		 'create'=>array(
'label'=>Yii::t('piano','New'),   
        		     'imageUrl'=>Yii::app()->request->baseUrl.'/images/configuracion/add.png',
            	 'url'=>'Yii::app()->createUrl("tiposPiano/create")',),
        		 'delete'=>array(
                'url'=>'Yii::app()->createUrl("tiposPiano/delete", array("id"=>$data->id))',),
          ),
       ),
	),
)); ?>
