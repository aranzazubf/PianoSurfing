<?php
class AleatorioPortadaWidget extends CWidget
{

		public $diccionario = 'app';	 	/* indica el diccionario del que se traducirán los términos*/
		
		public $ruta_css = 'application.assets.AleatorioPortadaWidget'; /* indica la ruta hacia los assets del widget*/
		
		public $archivo_css = 'aleatorioPortadaWidget.css'; /* nombre del archivo CSS */
		
		public $tag_mensaje = 'span';	/* indica el tag que englobará a la parte del mensaje recuperado de la BD, como mínimo span */	
		
		public $clase_estilo_msj = 'aleatorioPortada'; /* indica la clase que se le aplicará al mensaje para su formateado */
		
		public $pre_msj = ''; /* texto antes del mensaje aleatorio */
		
		public $post_msj = 'en torno a un piano.';	/* texto posterior al mensaje aleatorio*/
		
		public $item = 'AleatorioPortada'; /* tipo de item aleatorio que se recuperará de la BD */
		
		public $tag_oracion = 'h1'; /* tag html en el que se englobará todo el mensaje */
				
		public function init()
    	{
        // Este método lo llama CController::beginWidget()
    	}
		public function run()
    	{
   		/********************************************************************************************************************/
    		/* Obtenemos los segundos de la hora actual y le hacemos un cast a int por si hubiera problemas con los 00 a 09 (S) */
    		/********************************************************************************************************************/
			
			$random_num = (int) date('s',time());   		

			/******************************************************************************************************************************************************/			
			/* Obtenemos todos los items que hay y los contamos (N), le hacemos el módulo al número de segundos (S) con ese número (N) -el cero cuenta por lo     */
			/* que añadimos uno- de items y recuperamos de la BD el item ((S) mod (N)+1) de manera que nuestro aleatorio se basa en el segundo en el que estemos  */
			/******************************************************************************************************************************************************/
			
			$random_message = RandomMessage::item($this->item, 1+($random_num % (count(RandomMessage::items($this->item)))));    		
    		
    		/**********************************************************************/
    		/* Construimos con todo el mensaje traduciendo lo recuperado de la BD */
    		/**********************************************************************/
    		
    		//$mensaje = Yii::t($this->diccionario,'<'.$this->tag_oracion.'>'.$this->pre_msj.'<'.$this->tag_mensaje.' class="'.$this->clase_estilo_msj.'">'.$random_message.'</'.$this->tag_mensaje.'>&nbsp;'.$this->post_msj.'</'.$this->tag_oracion.'>');
    		$mensaje = Yii::t($this->diccionario,'<'.$this->tag_oracion.'>'.$this->pre_msj.'<'.$this->tag_mensaje.' class="'.$this->clase_estilo_msj.'">'.$random_message.'&nbsp;'.$this->post_msj.'</'.$this->tag_mensaje.'></'.$this->tag_oracion.'>');
			/*************************************************************/    		
    		/* Renderizamos la vista pasándole el mensaje como parámetro */
    		/*************************************************************/
    		
    		$this->render('aleatorioPortadaWidget',array('mensaje' => $mensaje));
    	}
}
?>