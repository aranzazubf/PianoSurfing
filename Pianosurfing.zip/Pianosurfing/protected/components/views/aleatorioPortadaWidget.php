<?php

	Yii::app()->clientScript->registerCssFile(Yii::app()->assetManager->publish(Yii::getPathOfAlias($this->ruta_css).'/'.$this->archivo_css));

	echo '<'.$this->tag_oracion.'>'.$mensaje.'</'.$this->tag_oracion.'>';

?>