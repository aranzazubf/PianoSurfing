<?php
return CMap::mergeArray(

/*
 	 ********Este archivo es el complemento del console para el DESARROLLO-PRUEBA*******
 	 */
	require(dirname(__FILE__).'/console.php'),
	
	array(
	/*
		 ***********************CONEXION A LA BASE DE DATOS MYSQL****************+
		 */
		'components'=>array(
		'db'=>array(
			'connectionString' => 'mysql:host=localhost;dbname=pianosurfingbase',
			'emulatePrepare' => true,
			'username' => 'ara',
			'password' => '35467557q',
			'charset' => 'utf8',
			'tablePrefix' => 'tbl_',
		),
		
	
	),
)
);
