<?php
return CMap::mergeArray(

/*
 	 ********Este archivo es el complemento del console para la PRODUCCION*******
 	 */
	require(dirname(__FILE__).'/console.php'),
	
	array(
	
		/*
		 ***********************CONEXION A LA BASE DE DATOS MYSQL****************+
		 */
		'components'=>array(
	/*	'db'=>array(
			'connectionString' => 'mysql:host=labtdi.det.uvigo.es;dbname=pfc1',
			'emulatePrepare' => true,
			'username' => 'abarbero',
			'password' => '2hmjk3',
			'charset' => 'utf8',
			'tablePrefix' => 'tbl_',
		),*/
'db'=>array(
			'connectionString' => 'mysql:host=localhost;dbname=pianosurfing',
			'emulatePrepare' => true,
			'username' => 'ary',
			'password' => 'aryarycambiame',
			'charset' => 'utf8',
			'tablePrefix' => 'tbl_',
		),
		
	
	),
)
);
