<?php

/*
 *Con la siguiente sentencia podemos definir alias para localizar carpetas  no tener que escribir
 *la ruta entera de cada vez
 * Yii::setPathOfAlias('local','path/to/local-folder');
 */
 
/*
 *This is the main Web application configuration. Any writable
 * CWebApplication properties can be configured here.
 */
return array(
	/*
	 ********Establecemos los Paths de las carpetas********
	 */
	'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'..',
	
	/*
 	 ********Determinamos el nombre de nuestra app********
 	 */
	'name'=>'PianoSurfing',
  //'defaultController' => 'site', 
	 'defaultController' => 'site', 
	/*
 	 ********Determinamos el lenguaje por defecto********
 	 */
	//'sourceLanguage'=>'en',
	'language' => 'es',

	/*	
	
	
	/*
	 * preloading 'log' component
	 */
	'preload'=>array('log'),

	/*
 	 ********Importamos los archivos necesarios********
 	 */
	
	'import'=>array(
		'application.models.*',
		'application.components.*',
		'application.modules.user.models.*',//modulo user
      'application.modules.user.components.*',
      'application.extensions.mail.*',
      'application.modules.user.*',
      'application.modules.message.*',
		'application.modules.message.models.*',
 		'application.modules.message.components.*',
		'application.extensions.galleryManager.models.*',
      'application.extensions.galleryManager.*',
      'application.extensions.image.*',      
      'ext.mail.YiiMailMessage',//modulo user
	),
	
	/*
	 ********Módulos: User ********
 	 */
	'modules'=>array(
		/*
		 *****************MODULO USER PARA LA GESTION DE USUARIOS Y AUTENTICACION********************
		 */
			'user'=>array(
            # encrypting method (php hash function)
            'hash' => 'md5',
 
            # send activation email
            'sendActivationMail' => true,
 
            # allow access for non-activated users
            'loginNotActiv' => false,
 
            # activate user on registration (only sendActivationMail = false)
            'activeAfterRegister' => false,
 
            # automatically login from registration
            'autoLogin' => false,
 
            # registration path
            'registrationUrl' => array('/user/registration'),
 
            # recovery password path
            'recoveryUrl' => array('/user/recovery'),
 
            # login form path
            'loginUrl' => array('/user/login'),
 
            # page after login
            'returnUrl' => array('/user/profile'),
 
            # page after logout
            'returnLogoutUrl' => array('/user/login'),
        ),
        'message' => array(
            'userModel' => 'User',
            'getNameMethod' => 'getFullName',
            'getSuggestMethod' => 'getSuggest',
            'viewPath' => 'application.modules.message.views.message.default.'
        ),
      
			
	),
	/*
 	 ********Componentes: User, Request, UrlManager, ErrorHandler********
 	 */

	'components'=>array(
	'request'=>array(
			'enableCsrfValidation'=>true,
			'enableCookieValidation'=>true,),
	
		'user'=>array(
			'class'=>'WebUser',
			'loginUrl' => array('/user/login'),//modulo user
     	
      	'allowAutoLogin' => true,
      // 'identityClass' => 'PianoSurfingv1/models/User',
      // enable cookie-based authentication
      // 'identityCookie' => array(
      // 'name' => '_frontendUser', // unique for frontend
      // 'path'=>'/PianoSurfingv1/frontend'  // correct path for the frontend app.
      ),
  
		
		/*
		 *Beauty Urls
		 */
		
		'urlManager'=>array(
			'urlFormat'=>'path',
			'rules'=>array(
		'post/<id:\d+>/<title:.*?>'=>'post/view',
				'posts/<tag:.*?>'=>'post/index',
				'<controller:\w+>/<action:\w+>'=>'<controller>/<action>',
			),
		),
		
		/*
		 *Determina la acción que se lleva a cabo cuando se produce un error
		 */
		'errorHandler'=>array(
			// use 'site/error' action to display errors
			'errorAction'=>'error/error',
		),
		'mail' => array(
			'class' => 'ext.mail.YiiMail',
			'transportType' => 'smtp',
				'transportOptions'=>array(
							'host'=>'smtp.gmail.com',
							'encryption'=>'tls',
							'username'=>"pianosurfingapp@gmail.com",
			 				'password'=>"psapp2015",
							'port'=>465,
				),
			'viewPath' => 'application.views.mail',
			 'logging' => true,
			 'dryRun' => false
			 ),
		 'image'=>array(
            'class'=>'application.extensions.image.CImageComponent',
            // GD or ImageMagick
            'driver'=>'GD',
            // ImageMagick setup path
            /*'params'=>array('directory'=>'D:/Program Files/ImageMagick-6.4.8-Q16'),*/
      ),
	),

	/* Parámetros que queramos acceder desde cualquier sitio de la aplicacion
	 * using Yii::app()->params['paramName']*/
	 'params'=>array(	
		'emailAdmin'=>'pianosurfingapp@gmail.com',	 
	 
	 ),
	);
