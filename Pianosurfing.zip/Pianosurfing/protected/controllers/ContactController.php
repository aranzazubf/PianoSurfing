<?php

class ContactController extends GlobalFController
{
	public $defaultAction = 'contact';
	public function filters() {
	 	return array(
	 	'accessControl',);
	}
	
	public function accessRules()
   {
     return array(
        array('allow', 
            'actions' => array('contact','suggest','captcha'), 
            'users' => array('@'),),
               
        array('deny', 
            'users' => array('*'),),);
    }
    
	public function actions()
	{
		return array(
 			'captcha'=>array(
				'class'=>'CCaptchaAction',
				'backColor'=>0xFFFFFF,),
		);
	}

	public function actionContact()
	{
		$name=Yii::app()->user->username;
		$email=Yii::app()->user->email;
		$model=new ContactForm;
		if(isset($_POST['ContactForm']))
		{
			$model->attributes=$_POST['ContactForm'];

	
		$model->name=$name;
		$model->email=$email;
			Yii::log($model->name,"error");
			if($model->validate())
			{
				$type='ContactMessage';
				$this->messageContact($model,$type);							
				$this->emailContact($model);

				Yii::app()->user->setFlash('contactMessage',Yii::t('app','Thank you for contacting us. We will respond to you as soon as possible.'));
				$this->refresh();
			}
		}
	
		$this->render('contact',array('model'=>$model, 'name' => isset($name) ? $name : null, 'email'=>isset($email) ? $email : null,));
	}
	public function actionSuggest()
	{
		$model=new ContactForm;
		$name=Yii::app()->user->username;
		$email=Yii::app()->user->email;
		if(isset($_POST['ContactForm']))
		{
			$model->attributes=$_POST['ContactForm'];
		
			$model->name=$name;
			$model->email=$email;
			if($model->validate())
			{
				$type='SuggestMessage';
				$this->messageContact($model,$type);		
				
				$this->emailContact($model);
				Yii::app()->user->setFlash('suggestMessage',Yii::t('app','Thank you for contacting us. We will respond to you as soon as possible.'));
				$this->refresh();
				
			}
		}
		
		$this->render('suggest',array('model'=>$model, 'name' => isset($name) ? $name : null, 'email'=>isset($email) ? $email : null,));
	}
	
	private function messageContact($model,$typeMessage){
	
	$from=Yii::app()->user->id;
	$subject=$model->subject;
	$body=$model->body;
	$type=$typeMessage;	
	MessageModule::sendMessageSystem($type,$from,$subject,$body);
	
	}
	private function emailContact($model){
	$adminEmail=UserModule::getEmailAdmin();
	$to=$adminEmail;
	$from=$adminEmail;
	$subject=$model->subject.'['.$model->name.']';
	$body=$model->body;
	UserModule::sendMail($from,$to,$subject,$body);	
	
	
	
	
	}
	
	

	
	
}