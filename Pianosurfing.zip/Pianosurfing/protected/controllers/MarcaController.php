<?php

class MarcaController extends Controller
{
	
	public $layout='//layouts/column2';
	private $_model;
	
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
		//	'postOnly + delete', // we only allow deletion via POST request
		);
	}

	public function accessRules()
	{
		return array(
	array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('create'),
				'users'=>array('@'),
			),
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('update','delete'),
				'users'=>UserModule::getAdmins(),
			),
			
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/*
	public function actionCreate()
	{
		$model=new Marca;
		if(isset($_POST['Marca']))
		{
			$model->attributes=$_POST['Marca'];
			if($model->save()){
				if (Yii::app()->request->isAjaxRequest)
                {
                	Yii::log("paso por save e isAjax","error");
			 echo CJSON::encode(array(
                        'status'=>'success', 
                        'div'=>"Classroom successfully added"
                        ));
                    exit;  
           }
			else{		
			$this->redirect(Yii::app()->request->getUrlReferrer());
			}
		}
		}
		if (Yii::app()->request->isAjaxRequest)
        {
        	Yii::log("no hay post...","error");
            echo CJSON::encode(array(
                'status'=>'failure', 
                'div'=>$this->renderPartial('_form', array('model'=>$model), true,true)));
            exit;               
        }
        else
            $this->render('create',array('model'=>$model));
    		}
		 */
		 
	public function actionCreate()
	{
		$model=new Marca;
		if(isset($_POST['Marca']))
		{
			$model->attributes=$_POST['Marca'];
			if($model->save()){
				if (Yii::app()->request->isAjaxRequest)
                {
              			echo CJSON::encode(array(
                        'status'=>'success', 
                        'div'=>"Classroom successfully added"
                        ));
                    exit;  
           }
			else{		
			$this->redirect(Yii::app()->request->getUrlReferrer());
			}
		}
		}
		if (Yii::app()->request->isAjaxRequest)
        {
       
            echo CJSON::encode(array(
                'status'=>'failure', 
                'div'=>$this->renderPartial('_form', array('model'=>$model), true,true)));
            exit;               
        }
        else
            $this->render('create',array('model'=>$model));
    		}
		
	
	public function actionUpdate()
	{
		$model=$this->loadModel();
		if(isset($_POST['Marca']))
		{
			$model->attributes=$_POST['Marca'];
			if($model->save())
					$this->redirect(array('/confpianos/admin'));
		}

		$this->render('update',array(
			'model'=>$model,
		));
	}
	public function actionDelete()
	{
		$this->loadModel()->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('/confpianos/admin'));
	}

	public function loadModel()
	{
		if($this->_model===null)
		    {
		        if(isset($_GET['id']))
		        {
		            $condition='';
		            $this->_model=Marca::model()->findByPk($_GET['id'], $condition);
		        }
		        if($this->_model===null)
		            throw new CHttpException(404,'The requested page does not exist.');
		    }
		    return $this->_model;
	}

	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='marca-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
