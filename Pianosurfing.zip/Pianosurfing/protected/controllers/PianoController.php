<?php

class PianoController extends GlobalFController
{

	private $_model;
	public $country_name;
	public $layout='//layouts/column2';
	
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			//'postOnly + delete', // we only allow deletion via POST request
		);
	}

	public function accessRules()
	{
		return array(
		array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','markerspianos'),
				'users'=>array('*'),
			),
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','create','update','delete','mypianos','cargarbandera','loadcities','galeria'),
				'users'=>array('@'),
			),
			
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin'),
				'users'=>UserModule::getAdmins(),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	public function actionIndex()
	{
		
		$criteria=new CDbCriteria;
		$country_name= "";
		$criteria->addCondition('user_id <>'.Yii::app()->user->id);
		$criteria->addCondition('statuspiano>'.Piano::STATUS_BANNED);
		$count=Piano::model()->count($criteria);
		
		$pages=new CPagination($count);
    	$pages->pageSize=$this->NumPianosPag();
    
    	$pages->applyLimit($criteria);
		
		if(isset($_POST['country_search'])){
					
			$country_id=(int)$_POST['country_search'];
			if($country_id!=0){
			$criteria->addCondition('country_id ='.$country_id);
			$country_name=Country::item($country_id);
			}
		}
		$dataProvider=new CActiveDataProvider('Piano',array(
			'pagination'=>$pages,			
			'criteria'=>$criteria,	
				));
			
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
			'country'=>$country_name,
'count'=>$count,	
		));
	}
	public function actionMypianos()
	{
		$criteria=new CDbCriteria;
		$country_name= "";
		if(isset($_POST['country_search'])){
			$country_id=(int)$_POST['country_search'];
			$criteria->addCondition('country_id ='.$country_id);
			$country_name=Country::item($country_id);
			}
     	$criteria->addCondition('user_id='.Yii::app()->user->id);
  		$count=Piano::model()->count($criteria);
		$pages=new CPagination($count);
    	$pages->pageSize=$this->NumPianosPag();
      $pages->applyLimit($criteria);
		$dataProvider=new CActiveDataProvider('Piano',array(
			'pagination'=>$pages,			
			'criteria'=>$criteria,		
		));
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
			'country'=>$country_name,
			'count'=>$count,	));
			
	} 
	public function actionView()
	{
	    $piano=$this->loadModel();
	    $this->render('view',array(
	        'model'=>$piano,
	    ));
	}
 
 
 	public function actionCreate()
	{
		if(isset($_POST['cancel'])){
		$this->redirect('index');
		}
		$model=new Piano();
		$model->statuspiano=Piano::STATUS_ACTIVE;
		$max=$model->probeNumPianosId();
		if(!$max)$this->render('maxpianos');
		else{
		$this->performAjaxValidation($model);
		if(isset($_POST['Piano']))
		{
			$model->attributes=$_POST['Piano'];
			if($model->save()){
			$this->redirect(array('view','id'=>$model->id));
			}
		}
		$this->render('create',array(
			'model'=>$model,
		));
	}
	
	}

	public function actionUpdate()
	{
		$model=$this->loadModel();
		$this->performAjaxValidation($model);
		if(isset($_POST['cancel'])){
		$this->redirect(array('view','id'=>$model->id));
		}
		if(isset($_POST['Piano']))
		{
			$model->attributes=$_POST['Piano'];
  			if($model->save()){
  			$this->redirect(array('view','id'=>$model->id));
			}	
		}
		$this->render('update',array(
			'model'=>$model,
		));
	}
	public function actionDelete()
		{
			 $model=$this->loadModel();
			 if($model->isOwner())
		    {
		    
		    	$model->delete();
			
		      $this->redirect(array('mypianos'));
		    }
		    else{
		  	        throw new CHttpException(400,'Invalid request. Please do not repeat this request again.');
		        }
		}	 
	
	public function HayPianosUsuario($usario){
	$criteria=new CDbCriteria;
	$criteria->addCondition('user_id='.$usuario);
  	$count=Piano::model()->count($criteria);
	if($count)return true;
	else return false;
	
	}	
	
	
	
	public function actionCargarbandera()
		{
	
		if(isset($_POST['region_id'])){
				
			$country_id=(int)$_POST['region_id'];	
			
			$country=Country::model()->findByPk($country_id);
			
			$bandera=$country->isocode;
			$country_name=$country->country;
			echo CHtml::image(Yii::app()->request->baseUrl.'/images/banderas/24/'.$bandera.'.png','bandera',array("id"=>"bandera_country_id"));
					}
			else{
			echo '';			
			}
			}

			public function getCountryName(){
				return $this->country_name;
			}
	
	
	
	public function NumPianosPag(){
		$conf=new Confpianos();
		$piano_page_size=$conf->getParam('maxpianos');	
		return $piano_page_size;
	}
	
	
	
	
	
	
	public function savePhotoPiano($model,$value,$action){
	
		if ($value) {
			if($action=='update'){
			$old_file = $model->photo;	
			if ($old_file&&file_exists($old_file))
					unlink($old_file);
			}
			$dir=$this->params['pathImgPianos'].$model->user_id.'/'.$model->id.'/';
			if (!file_exists($dir)) {
    			mkdir($dir, 0777, true);}
			$file_name= $dir.$model->id.'.'.$value->extensionName;
			$value->saveAs($file_name);
			$model->photo=$file_name;
			$model->save();
				}
	}
	
	 
	  	public function actionMarkerspianos()
    {
       
        
        $xmldom = new DOMDocument("1.0");
        $xmldom->formatOutput = true;
        $node = $xmldom->createElement("markers");
        $parnode = $xmldom->appendChild($node);         
        
		$pianos=Piano::model()->findAll();
		
        foreach ($pianos as $piano){
            
       
            $node = $xmldom->createElement("marker");  
              $newnode = $parnode->appendChild($node);   
            $newnode->setAttribute('id',$piano->id);
            $newnode->setAttribute('lat',$piano->latitude);
            $newnode->setAttribute('long',$piano->longitude);
			   $newnode->setAttribute('user',$piano->user->username);
			   $newnode->setAttribute('type',TiposPiano::item($piano->category));
			   $newnode->setAttribute('marca',Marca::item($piano->marca));
			   $newnode->setAttribute('model',$piano->model);
			   $newnode->setAttribute('status',$piano->conservation);     
			   $newnode->setAttribute('edad',$piano->user->profile->birth);        
        
        }
      
        echo CJSON::ENCODE ($xmldom->saveXML()); 
        
    }	  
	  
	   
	  public function muestraFotoPiano($piano){
	  $criteria=new CDbCriteria(array(
	  'limit'=>1,
	    'condition'=>'gallery_id=' . $piano->gallery_id,
	  	));
	  	
	  $gallery_photo=GalleryPhoto::model()->findAll($criteria);
	  if($gallery_photo){
	  foreach($gallery_photo as $photo)
	  $foto_name=$photo->getPreview();
		 if($foto_name)
	return $foto_name;}
	  else return Yii::app()->request->baseUrl.'/images/pianos/SinImagen.png';

	  }
	  
	  
	  
	  
	  
	  
	  
	  
	public function loadModel()
	{
		    if($this->_model===null)
		    {
		        if(isset($_GET['id']))
		        {
		            $condition='';
		            $this->_model=Piano::model()->findByPk($_GET['id'], $condition);
		        }
		        if($this->_model===null)
		            throw new CHttpException(404,'The requested page does not exist.');
		    }
		    return $this->_model;
	}
	
	
	
	
	
	
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='piano-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
		
	
	
}
