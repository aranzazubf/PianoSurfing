<?php
/**
 * Italian message translations.
 *
 * @author duedweb
 *
 * @version $Id: $
 */
return array(
    'Add…' => 'Aggiungi',
    'Close' => 'Chiudi',
    'Description' => 'Descrizione',
    'Edit information' => 'Modifica Informazioni',
    'Edit' => 'Modifica',
    'Name' => 'Nome',
    'Remove' => 'Rimuovi',
    'Save changes' => 'Salva Modifiche',
    'Select all' => 'Seleziona tutto',
    'Drop Files Here…' => 'Rilascia i Files qui…',
    'Uploading images…' => 'Upload immagini…',
);